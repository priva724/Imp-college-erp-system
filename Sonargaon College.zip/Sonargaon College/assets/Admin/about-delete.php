<?php
 include 'db.php';
$aboutdlt = $_GET['aboutdlt'];
$delete = "DELETE FROM about WHERE id = $aboutdlt";
$ex1 = mysqli_query($con,$delete);
header("location:about.php");
 ?>