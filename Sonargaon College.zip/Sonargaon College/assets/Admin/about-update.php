
<!-- update php code here -->
<?php
 include 'db.php';
 session_start();
 $aboutup = $_GET['aboutup'];
 $select = "SELECT * FROM about WHERE id = $aboutup";
 $ex = mysqli_query($con,$select);
 $row =mysqli_fetch_array($ex);

 if(isset($_POST['update'])){
  $title = $_POST['title'];
  $aboutus = $_POST['aboutus'];
   
  $update = "UPDATE about SET title='$title',	aboutus='$aboutus' WHERE id = $aboutup";

      $quary = mysqli_query($con,$update);
      header("location:about.php");
      if($qauary){
      echo "<script>alert('Data update success')</script>";    
      }else{
      echo "<script>alert('Data update failed')</script>";
      } 

}
 ?>
<!-- update php code end -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
  <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
</head>
<body>
  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div>
        <h4 class="text-white text-center">About Update</h4>      
             <form method="post">
             <label for="title">Title</label>
              <input id="title" 
                name="title" 
                value="<?php echo $row['title'] ?>"
                class="form-control form-control-lg"
                placeholder="Enter Title"><br>
              <textarea name="aboutus" class="from-control"
               id="" cols="50" rows="20">
               <?php echo $row['aboutus'] ?>
              </textarea>

               <button name="update" class="btn btn-primary p-2 mt-2">
                Update</button>
             </form> 
        </div>
      </div>
    </div>
  </div>
</body>
</html>





