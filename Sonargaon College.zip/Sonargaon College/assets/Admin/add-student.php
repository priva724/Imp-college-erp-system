<!-- data insert php code start -->
<?php
 include 'db.php';
session_start();
if(isset($_POST['submit'])){
  $name = attack ($_POST['name']);
  $phone = attack ($_POST['phone']);
  $studentid = attack ($_POST['studentid']);
  $year = attack ($_POST['year']);
  $age = attack ($_POST['age']);
  $gender = attack ($_POST['gender']);
  $fathername = attack ($_POST['fathername']);
  $mothername = attack ($_POST['mothername']);
  $address = attack ($_POST['address']);
  $zela = attack ($_POST['zela']);
  $thana = attack ($_POST['thana']);
  $zip = attack ($_POST['zip']);
  $national = attack ($_POST['national']);
  $relegion = attack ($_POST['relegion']);
  $date = attack ($_POST['date']);
  $institute = attack ($_POST['institute']);
  $sscgroup = attack ($_POST['sscgroup']);
  $regino = attack ($_POST['regino']);
  $roll = attack ($_POST['roll']);
  $board = attack ($_POST['board']);
  $pssyear = attack ($_POST['pssyear']);
  $gpa = attack ($_POST['gpa']);
  $department = attack ($_POST['department']);
  $class = attack ($_POST['class']);
  $subname = json_encode($_POST['subname']);  

  // // $chk="";  
  // foreach($subname as $chk1)  
  //  {  
  //     $chk .= $chk1.",";  
  //  }
  $optional = $_POST['optional'];
  $pass= $_POST['pass']; 
  $imagename = $_FILES['image']['name'];
  $tmp_name = $_FILES['image']['tmp_name'];
  $upload = move_uploaded_file($tmp_name,"assets/images/".$imagename);

  $check = "SELECT * FROM add_student where studentid='$studentid'";
  $ex1 = mysqli_query($con,$check);
  $count = mysqli_num_rows($ex1);
  if($count>0){
    echo "<script>alert('Student ID already Exsits')</script>";
  }else{
    $insert = "INSERT INTO add_student(name,phone,studentid,year,
    age,gender,fathername,
    mothername,address,zela,thana,
    zip,national,relegion,date,institute,
    sscgroup,regino,roll,board,pssyear,
    gpa,department,class,subname,optional,pass,image)
    VALUES('$name','$phone','$studentid','$year',
    '$age','$gender','$fathername',
    '$mothername','$address','$zela','$thana',
    '$zip','$national','$relegion','$date',
    '$institute','$sscgroup','$regino',
    '$roll','$board','$pssyear','$gpa',
    '$department','$class','$subname ','$optional','$pass','$imagename')";
  
    $ex = mysqli_query($con,$insert);
    if($ex){
      
      echo "<script>window.location='add-student.php'</script>";
    }else{
      echo "<script>alert('Data insert failed')</script>";
    }
  }

}
function attack($data){
  $data = trim("$data");
  $data = stripslashes("$data");
  $data = htmlspecialchars("$data");
  return $data;
}
 ?>
<!-- insert php code end here -->

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />  
    <style>
      .body{
        font-family: var_dump;
      }
    </style>
  </head>

  <body onload="selectYear()" class="body">
 
    <!-- Main wrapper - style you can find in pages.scss --> 
    <div id="main-wrapper">      
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">
          <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>    
                    
            <a class="navbar-brand" href="index.php">
              <b class="logo-icon"></b>                             
              </b>

              <span class="logo-text">
             
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>                      
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
      
          <div class="navbar-collapse collapse" id="navbarSupportedContent">
          
            <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <!-- mega menu -->
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >                 
               </a>                
              </li>             
            </ul>                    
          </div>
        </nav>
      </header>
      <!-- End Topbar header -->  

      <!-- Left sidebar code include here  -->   
      <?php
       include_once 'main_menu.php';
      ?>
      
           
      <!-- Page wrapper  -->
      <div class="page-wrapper">
<!-- Admission form code start  -->
<div class="container-fluid">
  <div class="col-1">
      <a href="index.php"><h4 class="text-uppercase">Student</h4></a>
  </div> 
    <form class="row"  method="post" id="my-stud" enctype="multipart/form-data">
      <div class="col-md-4">
      <label for="StudentName" class="text-dark text-uppercase">Name<span class="text-danger">*</span></label><br>
      <input name="name" type="text" 
        id="StudentName" class="form-control form-control-lg"
        placeholder="Name" required="">
      </div>
  
      <div class="col-md-4">
      <label for="StudentID" class="text-dark text-uppercase">ID<span class="text-danger">*</span></label><br>
                    <input name="studentid" type="text"
                            id="StudentID" class="form-control form-control-lg"
                            placeholder="Studeant ID" required="">
      </div>
      <div class="col-md-4">
      <label for="phone" class="text-dark text-uppercase">Mobile
                      <span class="text-danger">*</span></label>
                    <input name="phone" type="text"
                            id="phone" class="form-control"
                            placeholder="Mobile" required="">
      </div>
  <div class="col-4" >
      <label for="yearSelection" class="text-dark text-uppercase">Session<span class="text-danger">*</span></label><br>
                            
      <!-- <select name="year" 
              required="required"
              class="form-control" id="yearSelection">
       </select><br> -->
       <select name="year" 
              required="required"
              class="form-control" >
              <option value="" selected disabled>--session--</option>
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2026-2027">2026-2027</option>
              <option value="2027-2028">2027-2028</option>
              <option value="2028-2029">2028-2029</option>
              <option value="2029-2030">2029-2030</option>
              <option value="2030-2031">2030-2031</option>
       </select>
  </div>

  
  <div class="col-4">
  <label for="Studentage" class="text-dark text-uppercase">DOB<span class="text-danger">*</span></label><br>
  <input name="age" type="date"
         id="Studentage" class="form-control form-control-lg"
         placeholder="Enter Studeant Age" required="required">               
  </div>

  <div class="col-lg-4">
  <h5 class="text-dark text-uppercase">Gender<span class="text-danger">*</span></h5>
  <input type="radio"  id="female" name="gender" value="FeMale">
  <label for="female">Female</label>
  <input type="radio"  id="male" name="gender" value="Male">
  <label for="male">Male</label> 
<input type="radio"  id="other" name="gender" value="other">
  <label for="other">Other</label>             
  </div>
  <div class="col-lg-6">
        <label for="F_name" class="text-dark text-uppercase">Father's Name<span class="text-danger">*</span></label><br>
         <input name="fathername" type="text"
                id="F_name" class="form-control form-control-lg"
                placeholder="Father Name" required="required">
                 
  </div>
<div class="col-lg-6">
<label for="M_name" class="text-dark text-uppercase">Mother's Name<span class="text-danger">*</span></label><br>
  <input name="mothername" type="text"
         id="M_name" class="form-control form-control-lg"
         placeholder="Mother Name" required="required">               
</div>
<div class="col-4">
<label for="date" class="text-dark text-uppercase">Admission Date<span class="text-danger">*</span></label></label>
<input type="date" name="date"
      required="required" class="form-control form-control-lg"
      id="date">
</div>

<div class="col-lg-4">
<label class="text-dark text-uppercase">Religion<span class="text-danger">*</span></label>
<select name="relegion" class="form-control form-control-lg">
<option selected disabled value="">--Religion--</option>
  <option name="relegion" value="Islam" class="form-control form-control-lg">Islam</option>
  <option name="relegion" value="hindu" class="form-control form-control-lg">Hindu</option>
  
  <option value="Other" class="form-control form-control-lg">Other's</option>
</select>
  </div>


<div class="col-4">
<label for="national" class="text-dark text-uppercase">Nationality<span class="text-danger">*</span></label>
      <select name="national" class="form-control" id="country">
        <option value="" selected="selected" disabled>--Country--</option>        
        
        <optgroup id="country-optgroup-Asia" label="Asia">
         
            <option value="BH" name="national">Bahrain</option>
            <option value="BD" active name="national">Bangladesh</option>
            <option value="BT" name="national">Bhutan</option>
           
            <option value="KH" name="national">Cambodia</option>
            <option value="CN" name="national">China</option>
            <option value="GE" name="national">Georgia</option>            
            <option value="IN" name="national">India</option>         
            <option value="KW" name="national">Kuwait</option>         
            <option value="OM" name="national" >Oman</option>
            <option value="PK" name="national" >Pakistan</option>          
            <option value="PH" name="national" >Philippines</option>
            <option value="QA" name="national" >Qatar</option>
            <option value="SA" name="national" >Saudi Arabia</option>            
        </optgroup>      
    </select>
</div>

  <div class="col-3">
    <label for="zela" class="text-dark text-uppercase">Distric<span class="text-danger">*</span></label>
    <input type="text" class="form-control form-control-lg"
          name="zela" required="required"
          placeholder="Distric">
  </div>
  <div class="col-3">
    <label for="thana" class="text-dark text-uppercase">Police-Station<span class="text-danger">*</span></label>
    <input type="text" class="form-control form-control-lg"
            name="thana" required="required"
            placeholder="Police-Station">
  </div>

  <div class="col-3">
      <label for="zip" class="text-dark text-uppercase">post-office<span class="text-danger">*</span></label></label>
      <input type="text" name="zip" placeholder="post-office"
      required="required" class="form-control form-control-lg"
      id="zip">
  </div>

  <div class="col-3">
  <label for="address" class="text-dark text-uppercase">Village/Road/Block<span class="text-danger">*</span></label>
      <input name="address" placeholder="Address" 
      required="required" class="form-control form-control-lg" 
      type="text" >
  </div>

<div class="col-12">
  <label for="" class="text-success text-uppercase">SSC Passing Info<span class="text-danger">*</span></label>
  <table>
    <thead>
      <tr>
        <th>Institute</th>
        <th>Group</th>
        <th>Registration NO</th>
        <th>Board Roll NO</th>
        <th>Board Name</th>
        <th>Passing Year</th>
        <th>GPA</th>
      </tr>
    </thead>
    <tbody class="bg-primary">
      <tr>
        <td><input name="institute" required="required" type="text" class="form-control "></td>
        <td><input name="sscgroup" required="required" type="text" class="form-control"></td>
        <td><input name="regino" required="required" type="number" class="form-control"></td>
        <td><input name="roll" required="required" type="number" class="form-control"></td>
        <td><input name="board" required="required" type="text" class="form-control"></td>
        <td><input name="pssyear" required="required" type="number" class="form-control"></td>
        <td><input name="gpa" required="required" type="text" class="form-control"></td>
      </tr>
    </tbody>
  </table>

</div>
<div class="col-6">
<label for="class" class="text-dark text-uppercase"> Group<span class="text-danger">*</span></label><br> 
<select name="department" class="form-select" id="dropDownId" onchange="display()">
  
  <option value="Science">Science</option>
  <option value="Commerce">Commerce</option>
  <option value="Arts">Art's</option>
</select>

<div id="first" style="display: none;">
<div class="accordion-body mx-2 lrnmore">
   <input type="checkbox" name="subname[]" checked value="201"> Bangla <br>
   <input type="checkbox" name="subname[]" checked value="107"> English <br>              
   <input type="checkbox" name="subname[]" checked value="176"> Chemistry <br>          
   <input type="checkbox" name="subname[]" checked value="174"> Physics <br>            
   <input type="checkbox" name="subname[]" checked value="275"> ICT<br> 
    
   <label for="hmath">
   <input type="radio"  id="hmath" name="subname[]" required value="265">Higher Math
   </label>
   <label for="sbiology">
   <input type="radio"  id="sbiology" name="subname[]" required value="178"> Biology
   </label>
   <h5 class="py-2 text-center text-uppercase text-dark bg-warning">OPTIONAL</h5>
  
     <input type="radio"  id="math" required name="optional" value="265">
     <label for="math">Higher Math</label>
     <input type="radio"  id="biology" required name="optional" value="178">
     <label for="biology">Biology</label> 
  
 </div>
</div>

<script>

</script>

  </div>

<div class="col-6">
      <label for="class" class="text-dark text-uppercase"> Class<span class="text-danger">*</span></label><br>
      <select name="class" class="form-select" 
                required="required"
                aria-label="Default select example">
        <option selected disabled>--Select Admission Class--</option>
        <option value="Inter-I">Inter-I</option>
        <!-- <option value="Inter-II">Inter-II</option> -->
      </select>
</div>


  <div class="col-6">
      <label for="image" class="text-dark text-uppercase">Chose Image</label><br>
      <input name="image" type="file"
            id="image" class="form-control form-control-lg"
            onchange="ImgShow(event)"
            accept="image/*"><br>             
  </div>
  <div class="col-4 py-2">
  <img id="output" src="assets/images/man.png" alt="man" width="100" height="100">
  </div>
  <div class="col-2">
<input type="password" hidden value="123456" name="pass"
      required="required" class="form-control form-control-lg"
      id="pass">
</div>
  <div class="col-2">
        <button name="submit" id="Submit" class="btn btn-primary p-2">Submit</button>        
    </div> 

</div>   
</form>
<!-- form code end -->
</div>
        

        <!-- footer code start -->       
        <footer class="footer text-center">
          
          <a href="index.php">Sonargaon College</a>.
        </footer>    
      </div>    
    </div>
    
<!-- Required Js files -->   
   <!-- subjict select js code start -->
  
   <script>
function display(){
    var e = document.getElementById("dropDownId");
    var index = e.selectedIndex;
    if(index==0){
        document.getElementById("first").style.display = 'block'
        document.getElementById("second").style.display = 'none'              
    }
    else if(index==1){
        document.getElementById("first").style.display = 'none'
        document.getElementById("second").style.display = 'block'       
    }
}
   </script>
   <!-- subjict select js code end -->

    <!-- insart data -->
    <script>
      $("#my-stud").submit(function(e){
        e.preventDefault;
      })
    </script>

<!-- checkbox click js code -->
<script type="text/javascript">
  $('input:checkbox').click(function(){
    var id = ($(this).attr('id'));
    var $inputs = $("#id")
    if($(this).is(":checked")){
      $("."+id).not(this).prop('disabled',true);
    }else{
      $("."+id).prop('disabled',false);
    }
  })
</script>
<!-- insert image view -->
    <script>
      function ImgShow(event){
          var image = document.getElementById("output");
          image.src = URL.createObjectURL(event.target.files[0]);
      }
</script>
    <!-- Year select js code start-->
    <script>
      function selectYear(){
        var d=new Date();
        var currentYear=d.getFullYear();
        var str = "<option class='text-center' value='0'> --Select Year-- </option>";

        for(var i=0; i<20;i++){
          str+="<option>"+ parseInt(currentYear+i) +"</option>";
        }
        document.getElementById('yearSelection').innerHTML=str;
      }
    </script>
<!-- Year select js code end-->

    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>

<!-- Develope by "Muhammad Mijanur Rahman, 
               " -->