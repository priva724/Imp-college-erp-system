<?php
 include 'db.php';
$subdet = $_GET['subdet'];
$delete = "DELETE FROM arts WHERE id = $subdet";
$ex1 = mysqli_query($con,$delete);
header("location:arts.php");
 ?>