  <!-- PHP code start -->
  <?php
  include 'db.php';
  session_start();
  $clsupdate = $_GET['clsupdate'];
  $select = "SELECT * FROM addclass WHERE id = $clsupdate";
  $ex = mysqli_query($con,$select);
  $row =mysqli_fetch_array($ex);
 
  if(isset($_POST['update'])){
   $class = $_POST['class'];
   $classcode = $_POST['classcode'];
   
   $update = "UPDATE addclass SET class='$class', classcode='$classcode' WHERE id = $clsupdate";
 
       $quary = mysqli_query($con,$update);
                header("location:add-class.php");
       if($qauary){
       echo "<script>alert('Data update success')</script>";    
       }else{
       echo "<script>alert('Data update failed')</script>";
       } 
 }   
  ?>
  <!-- PHP code end -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon college</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

  <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
    <!-- data table CSS cdn -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />  
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>  
  
</head>
<body>
  <div class="container-fluid bg-light-primary">
    <div class="container">
      <div class="row">
        <div class="col-12">
        <a href="index.php" ><h3 class="bg-primary 
                my-5 text-center text-white">[Update Class]</h3></a>
              <form id="subject" method="post">

              <label for="class">Select Class</label><br>
                  <select name="class" 
                  value="<?php echo $row['class'] ?>"
                   class="form-select"                        
                    aria-label="Default select example">
                    <option selected>Select Class</option>
                    <option value="Inter-I">Inter-I</option>
                    <option value="Inter-II">Inter-II</option>                    
                </select>
                    <label for="courseid">Class Code</label><br>
                    <input type="text" 
                    id="classcode" 
                    name="classcode" 
                    value="<?php echo $row['classcode'] ?>"
                    class="form-control form-control-lg"                    
                    placeholder="Enter Class ID">
                    <br>                    
                <button name="update" class="btn btn-primary p-2 mt-2">Update Class</button>
              </form> <br><br><br><br><br><br><br><br><br>
              <br><br><br><br><br><br><br><br><br>
              <br><br><br><br><br><br><br><br><br>

        </div>
      </div>
    </div>
  </div>




   <!-- Required Js files -->   
   
  <!-- data table code start -->
  <script>
      $(document).ready( function () {
    $('#myTable').DataTable();
      } );
    </script>
    <!-- data table code end -->


    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>