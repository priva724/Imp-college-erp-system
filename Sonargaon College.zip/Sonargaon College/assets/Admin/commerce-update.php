<!-- update php code here -->
<?php
 include 'db.php';
 session_start();
 $subupdate = $_GET['subupdate'];
 $select = "SELECT * FROM commerce WHERE id = $subupdate";
 $ex = mysqli_query($con,$select);
 $row =mysqli_fetch_array($ex);

 if(isset($_POST['update'])){
  $class = $_POST['class'];
  $subject = $_POST['subject'];
  $courseid = $_POST['courseid'];
  $optional = $_POST['optional'];
 
  $update = "UPDATE commerce SET class='$class', subject='$subject',
  courseid = '$courseid', optional='$optional' WHERE id = $subupdate";

      $quary = mysqli_query($con,$update);
      header("location:commerce.php");
      if($qauary){
      echo "<script>alert('Data update success')</script>";    
      }else{
      echo "<script>alert('Data update failed')</script>";
      } 

}
 ?>
<!-- update php code end -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
  <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
    <!-- data table CSS cdn -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />  
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>  
  
</head>
<body>
  
<div class="container-fluid bg-light-cyan">
  <div class="container">
    <div class="row">
      
      <div class="col-12 my-5 ">
      <h2 class="bg-success text-white text-center">Subject Update</h2>
      <form id="subject" method="post">

                <label for="subject">Subject Name</label><br>
                <input type="text" 
                id="subject" 
                name="subject"
                value="<?php echo $row['subject'] ?>"
              
                class="form-control form-control-lg"
                placeholder="Enter Subject Name">

                <label for="courseid">Course ID</label><br>
                <input type="text" 
                id="courseid" 
                name="courseid" 
                value="<?php echo $row['courseid'] ?>"
                class="form-control form-control-lg"               
                placeholder="Enter Course ID"><br>
               
                <br>
                <button name="update" class=" btn btn-primary p-2 mt-2">Update Subject</button>
            </form><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br>
      </div>
    </div>
  </div>
</div>

 <!-- Bootstrap tether Core JavaScript -->
 <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->   
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>