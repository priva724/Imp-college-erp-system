<!-- subject details php insert code here -->

<?php 
include 'db.php';
if(isset($_POST['submit'])){
  $subject_code = $_POST['subject_code'];
  $subject_title = $_POST['subject_title'];
  $subject_exam_type = $_POST['subject_exam_type'];
  $subject_type = $_POST['subject_type'];
  $dept = $_POST['dept'];

  $check = "SELECT * FROM subject_details where subject_code='$subject_code'";
  $ex1 = mysqli_query($con,$check);
  $count = mysqli_num_rows($ex1);
  if($count>0){
    echo "<script>alert('Subject code already Exsits')</script>";
  }else{
    $insert= "INSERT INTO `subject_details` (`subject_code`, 
    `subject_title`, `subject_exam_type`, `subject_type`, `dept`) VALUES 
    ('$subject_code', '$subject_title', '$subject_exam_type', 
    '$subject_type', '$dept')";
  
    $ex = mysqli_query($con,$insert); 
    if($ex){
      echo "<script>window.location='subject_details.php'</script>";
    }else{
      echo "<script>alert('Data insert failed')</script>";
    }
  }
}
?>
<!-- subject details end here -->

