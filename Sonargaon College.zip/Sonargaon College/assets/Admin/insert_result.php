<?php
include 'db.php';
 session_start();
 if(isset($_POST['submit'])){
  $studentid = $_POST['studentid'];
  $department = $_POST['department'];
  $cq = $_POST['cq'];
  $lab = $_POST['lab'];
  $mcq = $_POST['mcq'];
  $marks = $_POST['marks'];
  $subject_code = $_POST['subject_code'];
 
foreach($cq as $key => $value){
  $insert = "INSERT INTO tblresult(studentid,subject_code,department,cq,lab,mcq,marks) 
  VALUES('$studentid[$key]','$subject_code[$key]','$department[$key]','$cq[$key]',
  '$lab[$key]','$mcq[$key]','$marks[$key]')";
  $ex = mysqli_query($con,$insert);
  if($ex){
    echo "<script>window.location='student_result.php'</script>";
  }else{
    echo "<script>alert('Data insert failed')</script>";
  }
}

 }
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

  <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />  
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>  
 
  </head>
  <body>

    <!-- Main wrapper - style you can find in pages.scss -->  
    <div id="main-wrapper">  
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">
            <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>       
            <a class="navbar-brand" href="index.php">
              
              
              <!-- Logo text -->
              <span class="logo-text">
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>        
            <!-- End Logo -->            
        
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
         <!-- End Logo -->
         <div class="navbar-collapse collapse" id="navbarSupportedContent">
            <!-- toggle and nav items -->
           <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <!-- mega menu -->
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
               
                </a>                
              </li>           
                     
            </ul>                              
          </div>
        </nav>
      </header>
      <!-- End Topbar header -->
   
      <!-- Left Sidebar include here --> 
      <?php
       include_once 'main_menu.php';
      ?>

  <!-- Page wrapper Start -->
    <div class="page-wrapper">       
       <div class="container-fluid">       
        <!-- main page code start -->
         <div class="row">
         <div class="overflow-scroll">    
         <h3 class="text-white text-center bg-success py-2">Exam Result</h3>
 
         <form method="POST">
           <table class="table table-bordered display table-striped overflow-scroll">
              <thead class="text-uppercase">
                <tr>
                  <th>Subject Name</th>
                  <th>Subject Code</th>
                  <th>Theory</th>
                  <th>Practical</th>
                  <th>MCQ</th>
                  <th>Total Marks</th>
                  <th>Grading</th>
                  
                </tr>
              </thead>
              <tbody>
             
                <?php 
                $select = "SELECT * FROM add_student";
                $quary = mysqli_query($con,$select );               
                $row = mysqli_fetch_array($quary) ;
                
                ?>
             
                  
                  <?php
                if(isset($_GET['stdresult'])) {
                  $id = $_GET['stdresult'];
                  $query = "SELECT `subname`, `department`,`studentid`,`optional` 
                  FROM `add_student` WHERE `id` = $id";
                  $all_subjects = "SELECT * FROM `subject_details` ";
              
                  // Execute the query
                  $result = mysqli_query($con, $query);
                  $query_result = mysqli_query($con, $all_subjects);
                  // $result_subject = mysqli_fetch_assoc($query_result);
                  $subjects = mysqli_fetch_all($query_result, MYSQLI_ASSOC);


              
                  if ($result) {
                      $row = mysqli_fetch_assoc($result);        
                      if ($row) {
                          // echo "Subject Name: " . $row['department'];
                        $subjects = json_decode($row['subname']);
                        foreach ($subjects as $index => $value) { ?>
                        <tr>
                          <td> <?php
                           if ($value == 201) {
                             echo 'Bangla';
                             ?>   <input type="number" name="subject_code[]" value="201"  hidden>   
                               <?php
                           }elseif($value == 107) {
                            echo 'English';
                            ?>   <input type="number" name="subject_code[]" value="107"  hidden>     
                            <?php
                           }elseif($value == 174) {
                            echo 'Physics ';
                            ?>   <input type="number" name="subject_code[]" value="174"  hidden>    
                             <?php
                           }
                           elseif($value == 176) {
                            echo 'Chemistry ';
                            ?>   <input type="number" name="subject_code[]" value="176"  hidden>    
                             <?php
                           }elseif($value == 275) {
                            echo 'Information and Communications Technology ';
                            ?>   <input type="number" name="subject_code[]" value="275"  hidden>    
                             <?php
                           }
                           elseif($value == 265) {
                            echo 'Mathematics ';
                            ?>   <input type="number" name="subject_code[]" value="265"  hidden>    
                             <?php
                           }elseif($value == 178) {
                            echo 'Biology ';
                            ?>   <input type="number" name="subject_code[]" value="178"  hidden>    
                            <?php
                           }
                           else{
                            echo 'Subject not found';
                           }
                          ?> </td>     
                        
                        <td>
                            <?php echo "$value"  ?>
                        </td>
                          
                        <td><input name="cq[]" type="number" class="form-control amount"></td>
                        <td><input name="lab[]" type="number" class="form-control amount"></td>
                        <td><input name="mcq[]" type="number" class="form-control amount"></td>
                        <td><input name="marks[]" type="number" readonly class="form-control amount"></td>
                        <td><input name="latter[]" type="number" readonly class="form-control amount"></td> 
                       

                        <input type="text" name="student_id"  value=" <?php echo $id  ?> " hidden> 
                       <?php ?> 
                       <input type="text" name="department[]"  value=" <?php echo  $row['department']  ?> " hidden> 
                       <input type="text" name="studentid[]"  value=" <?php echo  $row['studentid']  ?> " hidden> 
                       
                        </tr>    
                                        
                      <?php  
                       }
                      } else {
                          echo "No data found for ID: $id";
                      }
                      ?> <?php 
                      
                  }              
                } else {
                    echo "ID not found in the URL";
                }
                ?>  
                  </tbody>
            </table> 
                <button name="submit" class="btn btn-success">Submit</button>
                 </form> 
            
            
                 
        </div>   
        <div class="col-2 mt-2">
            <a href="student_result.php"><button class="btn btn-warning">Back</button></a>
          </div> 
      </div>
     </div>
<!-- Page wrapper End  -->

        <!-- footer code start -->       
        <footer class="footer text-center">       
          <a href="index.php"> Sonargaon College</a>.
        </footer>    
      </div>    
    </div>

    <!-- Required Js files -->  

     <!-- data table code start -->
    <script>
      $(document).ready( function () {
    $('#myTable').DataTable();
      } );
    </script>
   
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>
