<?php
 include 'db.php';
$marqdlt = $_GET['marqdlt'];
$delete = "DELETE FROM marquee WHERE id = $marqdlt";
$ex1 = mysqli_query($con,$delete);
header("location:marquee.php");
 ?>