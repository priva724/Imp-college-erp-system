<!-- update php code here -->
<?php
 include 'db.php';
 session_start();
 $marqup = $_GET['marqup'];
 $select = "SELECT * FROM marquee WHERE id = $marqup";
 $ex = mysqli_query($con,$select);
 $row =mysqli_fetch_array($ex);

 if(isset($_POST['update'])){
  $title = $_POST['title'];
  $update = "UPDATE marquee SET title='$title' WHERE id = $marqup";

      $quary = mysqli_query($con,$update);
      header("location:marquee.php");
      if($qauary){
      echo "<script>alert('Data update success')</script>";    
      }else{
      echo "<script>alert('Data update failed')</script>";
      } 

}
 ?>
<!-- update php code end -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
  <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
</head>
<body>
  <div class="container-fluid bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div>
         <h2  class="mt-5 text-center">Marqauee Update</h2>
                  <form method="post">
                   
                    <label for="title">Title</label><br>
                    <textarea name="title"                   
                    id="title"                     
                    class="form-control"                
                    cols="20" rows="10"><?php echo $row['title'] ?></textarea>

                    <button name="update" class=" btn btn-warning p-2 mt-2">Update</button>
                  </form><br><br><br><br><br><br><br><br><br><br><br>
          </div>
        </div>
      </div>
    </div>
  </div>


  
    <!-- Required Js files -->   
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>