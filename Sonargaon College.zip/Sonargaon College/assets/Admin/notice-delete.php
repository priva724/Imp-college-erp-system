<?php
 include 'db.php';
$noticedlt = $_GET['noticedlt'];
$delete = "DELETE FROM noticeboard WHERE id = $noticedlt";
$ex1 = mysqli_query($con,$delete);
header("location:notice.php");
 ?>