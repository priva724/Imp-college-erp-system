<!-- update php code here -->
<?php
 include 'db.php';
 session_start();
 $noticeup = $_GET['noticeup'];
 $select = "SELECT * FROM noticeboard WHERE id = $noticeup";
 $ex = mysqli_query($con,$select);
 $row =mysqli_fetch_array($ex);

 if(isset($_POST['update'])){
  $title = $_POST['title'];
  $image = $_POST['image'];
  $notice = $_POST['notice'];
 
  $update = "UPDATE noticeboard SET title='$title', image='$image',
  notice = '$notice' WHERE id = $noticeup";

      $quary = mysqli_query($con,$update);
      header("location:notice.php");
      if($qauary){
      echo "<script>alert('Data update success')</script>";    
      }else{
      echo "<script>alert('Data update failed')</script>";
      } 

}
 ?>
<!-- update php code end -->


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
  <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
</head>
<body>
  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="notice">
          <h2  class="mt-5 text-center">Notice Board Update</h2>
          <form method="POST">
             <label for="title">Title</label>
                  <input type="text"
                   placeholder="Enter Title"
                   class="form-control"                  
                   id="title" 
                   value="<?php echo $row['title'] ?>"             
                   name="title"><br>

                   <input type="file" name="image"><br>
                   <!-- value="<?//php echo $row['clg'] ?>" -->

                   <label for="notice">Notice</label><br>
                   <textarea name="notice" id="notice" 
                   class="form-control"               
                   cols="30" rows="10">
                  <?php echo $row['notice'] ?>
                   </textarea><br>
                   <button name="update" class="btn btn-primary p-2 mt-2">
                Update</button>
             </form>
          </div>
        </div>
      </div>
    </div>
  </div>

     <!-- Required Js files -->   
     <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>