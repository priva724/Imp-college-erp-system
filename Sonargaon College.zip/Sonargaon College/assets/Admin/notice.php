<?php
include 'db.php';
session_start();
 if(isset($_POST['submit'])){
  $title = $_POST['title'];
  $notice = $_POST['notice'];
 
  $imagename = $_FILES['image']['name'];
  $tmp_name = $_FILES['image']['tmp_name'];
  $upload = move_uploaded_file($tmp_name,"assets/images/".$imagename);

  $insert = "INSERT INTO noticeboard(title,image,notice)
  VALUES('$title','$imagename','$notice')";

   $ex = mysqli_query($con,$insert);
      if($ex){
        echo "<script>alert('Data insert success')</script>";
        echo "<script>window.location='notice.php'</script>";
      }else{
        echo "<script>alert('Data insert failed')</script>";
      }
}

?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

  <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
  </head>
  <body>

    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
      <svg
        class="tea lds-ripple"
        width="37"
        height="48"
        viewbox="0 0 37 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M27.0819 17H3.02508C1.91076 17 1.01376 17.9059 1.0485 19.0197C1.15761 22.5177 1.49703 29.7374 2.5 34C4.07125 40.6778 7.18553 44.8868 8.44856 46.3845C8.79051 46.79 9.29799 47 9.82843 47H20.0218C20.639 47 21.2193 46.7159 21.5659 46.2052C22.6765 44.5687 25.2312 40.4282 27.5 34C28.9757 29.8188 29.084 22.4043 29.0441 18.9156C29.0319 17.8436 28.1539 17 27.0819 17Z"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          d="M29 23.5C29 23.5 34.5 20.5 35.5 25.4999C36.0986 28.4926 34.2033 31.5383 32 32.8713C29.4555 34.4108 28 34 28 34"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          id="teabag"
          fill="#2962FF"
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M16 25V17H14V25H12C10.3431 25 9 26.3431 9 28V34C9 35.6569 10.3431 37 12 37H18C19.6569 37 21 35.6569 21 34V28C21 26.3431 19.6569 25 18 25H16ZM11 28C11 27.4477 11.4477 27 12 27H18C18.5523 27 19 27.4477 19 28V34C19 34.5523 18.5523 35 18 35H12C11.4477 35 11 34.5523 11 34V28Z"
        ></path>
        <path
          id="steamL"
          d="M17 1C17 1 17 4.5 14 6.5C11 8.5 11 12 11 12"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke="#2962FF"
        ></path>
        <path
          id="steamR"
          d="M21 6C21 6 21 8.22727 19 9.5C17 10.7727 17 13 17 13"
          stroke="#2962FF"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        ></path>
      </svg>
    </div>

    <!-- Main wrapper - style you can find in pages.scss -->  
    <div id="main-wrapper">
      <!-- Topbar header - style you can find in pages.scss -->      
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">
            <!-- This is for the sidebar toggle which is visible on mobile only -->
            <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>
     
            <!-- Logo -->            
            <a class="navbar-brand" href="index.php">
              <!-- Logo icon -->
              <b class="logo-icon"></b>                             
              </b>
              <!--End Logo icon -->
              
              <!-- Logo text -->
              <span class="logo-text">
                <!-- dark Logo text -->
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>
            
            <!-- End Logo -->            
            <!-- Toggle which is visible on mobile only -->           
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
         <!-- End Logo -->
         <div class="navbar-collapse collapse" id="navbarSupportedContent">
            <!-- toggle and nav items -->
           <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <!-- mega menu -->
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <span class="d-none d-md-block"
                    >Sonargaon College <i data-feather="chevron-down" class="feather-sm"></i
                  ></span>
                  <span class="d-block d-md-none"><i class="ri-keyboard-line"></i></span>
                </a>                
              </li>           
              <!-- End mega menu -->          
            </ul>            
            <!-- Right side toggle and nav items -->           
          </div>
        </nav>
      </header>

      <!-- End Topbar header -->
   
      <!-- Left Sidebar - style you can find in sidebar.scss  -->
   
      <?php
       include_once 'main_menu.php';
      ?>

      <!-- End Left Sidebar - style you can find in sidebar.scss  -->
      
      <!-- Page wrapper  -->

      <div class="page-wrapper">
        
        <!-- Container fluid  -->  
        <div class="container-fluid">       
          <!-- main page code start -->

          <div class="row">
            <div class="col-5">
             <a href="index.php"><h4>Dashboard</h4></a>
             <form method="POST" enctype="multipart/form-data">
             <label for="title">Title</label>
                  <input type="text"
                   placeholder="Enter Title"
                   class="form-control"
                   id="title"
                   required="required"
                   name="title"><br>

                   <label for="image">Chose Image</label><br>
                   <input name="image" type="file"
                        
                        id="image" class="form-control form-control-lg"
                        onchange="ImgShow(event)"
                        accept="image/*">
                    <img id="output" src="assets/images/man.png" alt="man" width="100" height="100"><br>

                   <label for="notice">Notice</label><br>
                   <textarea name="notice" id="notice" 
                   class="form-control"
                   required="required"
                   cols="30" rows="10">

                   </textarea><br>
                   <button name="submit" class="btn btn-primary p-2 mt-2">
                Submit</button>
             </form>
             </div>
             <div class="col-7">
                 <table class="table table-bordered display">
                    <thead>
                      <tr>
                        <th>SL</th>
                        <th>Title</th>
                        <th>Image</th>
                        <th>Notice</th>
                        <th>Update</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                      $select = "SELECT * FROM noticeboard";
                      $quary = mysqli_query($con,$select);
                      $count=1;
                      while($row = mysqli_fetch_array($quary)){ ?>
                          <tr>
                                <td><?php echo $count++ ?></td>
                                <td><?php echo $row['title'] ?></td>
                                <td><img width="100" height="100" 
                                    src="assets/images/<?php echo $row['image'] ?>"
                                    alt="">
                                </td>
                                <td><?php echo $row['notice'] ?></td>

                                <td><a href="notice-update.php?noticeup=<?php echo $row['id']?>">
                                <button class="btn btn-success">Update</button></a></td>
                                <td><a onclick="return confirm('are you sure?')" href="notice-delete.php?noticedlt=<?php echo $row['id']?>" href="notice-delete.php"><button class="btn btn-danger">Delete</button></a>
                            </td> 
                             </tr>
                    <?php
                      }
                    ?>
                    </tbody>
                 </table>
             </div>
           </div>
          </div>
        
        </div>


        <!-- footer code start -->       
        <footer class="footer text-center">       
          <a href="index.php"> Sonargaon College</a>.
        </footer>    
      </div>    
    </div>

    <!-- Required Js files --> 
    <script>
      function ImgShow(event){
          var image = document.getElementById("output");
          image.src = URL.createObjectURL(event.target.files[0]);
      }
    </script>

    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>
