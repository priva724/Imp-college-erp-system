<!-- update php code here -->
<?php
 include 'db.php';
 session_start();
 $princup = $_GET['princup'];
 $select = "SELECT * FROM principal WHERE id = $princup";
 $ex = mysqli_query($con,$select);
 $row =mysqli_fetch_array($ex);

 if(isset($_POST['update'])){
  $title = $_POST['title'];
  $image = $_POST['image'];
  $message = $_POST['message'];
  $name = $_POST['name'];
  $post = $_POST['post'];
  $clg = $_POST['clg'];
 
  $update = "UPDATE principal SET title='$title', image='$image',
  message = '$message',name = '$name',post = '$post',clg = '$clg' WHERE id = $princup";

      $quary = mysqli_query($con,$update);
      header("location:principal.php");
      if($qauary){
      echo "<script>alert('Data update success')</script>";    
      }else{
      echo "<script>alert('Data update failed')</script>";
      } 

}
 ?>
<!-- update php code end -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
  <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
</head>
<body>
  <div class="container-fluid bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div>
         <h2  class="mt-5 text-center">Head Teacher info Update</h2>
                  <form method="post">
                    <label for="title">Update Title</label>
                    <input type="text" placeholder="Enter title"
                    name="title"
                    value="<?php echo $row['title'] ?>"
                  
                    class="form-control"><br>

                    <label for="">Update Image</label><br>
                    <input type="file" 
                    placeholder="image"
                    value="<?php echo $row['image'] ?>" 
                    name="img"><br>

                    <label for="message">Update Message</label><br>
                    <textarea name="message"                   
                    id="message"                     
                    class="form-control"                
                    cols="20" rows="10"><?php echo $row['message'] ?></textarea>

                    <label for="name">Update Name</label>
                    <input type="text" name="name"
                    value="<?php echo $row['name'] ?>"
                    placeholder="Enter Name"
                   
                    class="form-control">

                    <label for="post">Update Position</label>
                    <input type="text" name="post"
                    value="<?php echo $row['post'] ?>"
                    placeholder="Enter Position"                  
                    class="form-control">

                    <label for="clg">Update College-Name</label>
                    <input type="text" name="clg"
                    value="<?php echo $row['clg'] ?>"
                    placeholder="Enter College Name"            
                    class="form-control"><br>
                    <button name="update" class=" btn btn-warning p-2 mt-2">Update Message</button>
                </form>
                <br><br><br><br><br><br><br><br><br><br><br>
          </div>
        </div>
      </div>
    </div>
  </div>


  
    <!-- Required Js files -->   
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>