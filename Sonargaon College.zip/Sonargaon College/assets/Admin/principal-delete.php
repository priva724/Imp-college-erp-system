
<?php
 include 'db.php';
$princdlt = $_GET['princdlt'];
$delete = "DELETE FROM principal WHERE id = $princdlt";
$ex1 = mysqli_query($con,$delete);
header("location:principal.php");
 ?>