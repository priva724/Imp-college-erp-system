<!-- serarching code start here -->
<!-- <?php
include 'db.php';
 $query = "";
 $subtype = "";
$studentid = $_REQUEST['studentid'];
$year = $_REQUEST['year'];
$department = $_REQUEST['department'];
if(isset($studentid)){//if keyword set goes here
  $query = "SELECT * FROM add_student WHERE studentid LIKE '%$studentid%' 
  AND year LIKE '%$year%' AND department LIKE '%$department%'";
   if(isset($department)){
     $query = "AND department LIKE '%$department%'";
   }
   if(isset($year)){
     $query = "AND year LIKE '%$year%'";
   }
}else if (isset($studentid)){ //if keyword not set but category set then goes here
  $query = "SELECT * FROM add_student WHERE studentid LIKE '%$studentid%'";
  if(isset($year)){
    $query  = "AND year LIKE '%$year%'";
  }
}else if(isset($department)){//if only country set goes here
  $query = "SELECT * FROM add_student WHERE department LIKE '%$department%'";
}
?> -->
<!-- php result insert code start -->
<?php
 session_start();
 if(isset($_POST['submit'])){
 
  $cq = $_POST['cq'];
  $lab = $_POST['lab'];
  $mcq = $_POST['mcq'];
  $marks = $_POST['marks'];
foreach($cq as $key => $value){
  $insert = "INSERT INTO tblresult(cq,lab,mcq,marks) 
  VALUES('$cq[$key]','$lab[$key]','$mcq[$key]','$marks[$key]')";
  $ex = mysqli_query($con,$insert);
  if($ex){
    echo "<script>window.location='result.php'</script>";
  }else{
    echo "<script>alert('Data insert failed')</script>";
  }
}

 }
?>
<!-- php result insert code end -->

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

  <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <link rel="stylesheet" href="assets/css/apexcharts.css" />   
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
  </head>
  <body onload="selectYear()">

    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
      <svg
        class="tea lds-ripple"
        width="37"
        height="48"
        viewbox="0 0 37 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M27.0819 17H3.02508C1.91076 17 1.01376 17.9059 1.0485 19.0197C1.15761 22.5177 1.49703 29.7374 2.5 34C4.07125 40.6778 7.18553 44.8868 8.44856 46.3845C8.79051 46.79 9.29799 47 9.82843 47H20.0218C20.639 47 21.2193 46.7159 21.5659 46.2052C22.6765 44.5687 25.2312 40.4282 27.5 34C28.9757 29.8188 29.084 22.4043 29.0441 18.9156C29.0319 17.8436 28.1539 17 27.0819 17Z"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          d="M29 23.5C29 23.5 34.5 20.5 35.5 25.4999C36.0986 28.4926 34.2033 31.5383 32 32.8713C29.4555 34.4108 28 34 28 34"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          id="teabag"
          fill="#2962FF"
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M16 25V17H14V25H12C10.3431 25 9 26.3431 9 28V34C9 35.6569 10.3431 37 12 37H18C19.6569 37 21 35.6569 21 34V28C21 26.3431 19.6569 25 18 25H16ZM11 28C11 27.4477 11.4477 27 12 27H18C18.5523 27 19 27.4477 19 28V34C19 34.5523 18.5523 35 18 35H12C11.4477 35 11 34.5523 11 34V28Z"
        ></path>
        <path
          id="steamL"
          d="M17 1C17 1 17 4.5 14 6.5C11 8.5 11 12 11 12"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke="#2962FF"
        ></path>
        <path
          id="steamR"
          d="M21 6C21 6 21 8.22727 19 9.5C17 10.7727 17 13 17 13"
          stroke="#2962FF"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        ></path>
      </svg>
    </div>

    <!-- Main wrapper - style you can find in pages.scss -->  
    <div id="main-wrapper">      
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">
           <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>                      
            <a class="navbar-brand" href="index.php">
              <b class="logo-icon"></b>                             
              </b>              
              <span class="logo-text">              
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>           
            <!-- Toggle which is visible on mobile only -->           
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
         <div class="navbar-collapse collapse" id="navbarSupportedContent">
            <!-- toggle and nav items -->
           <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <!-- mega menu -->
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >                 
               </a>                
              </li>                               
            </ul>                              
          </div>
        </nav>
      </header>

      <!-- End Topbar header -->   
  <?php 
     include_once 'main_menu.php';
    ?>
      <!-- Page wrapper  -->
      <div class="page-wrapper">        
        <!-- Container fluid  -->  
        <div class="container-fluid bg-white">       
          <div class="row">
            <div class="result">
            <form method="post" class="row">
              <div class="col-md-4">
              <label for="stid">Student ID<span class="text-danger">*</span></label><br>
                <input id="stid" type="text" 
                       name="studentid"
                       require="require" 
                       placeholder="Student ID" 
                       class="form-control"><br>
              </div>
              <div class="col-4" >
              <label for="yearSelection" class="text-dark text-uppercase">
                Session<span class="text-danger">*</span></label><br>                           
              <!-- <select name="year" 
                      required="required"
                      class="form-control" id="yearSelection">
              </select><br> -->
              <select name="year" 
              required="required"
              class="form-control" >
              <option value="" selected disabled>--session--</option>
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2026-2027">2026-2027</option>
              <option value="2027-2028">2027-2028</option>
              <option value="2028-2029">2028-2029</option>
              <option value="2029-2030">2029-2030</option>
              <option value="2030-2031">2030-2031</option>
       </select>
              </div>
              <div class="col-md-4">
               
                    <label for="department">Group<span class="text-danger">*</span></label><br>
                    <select name="department" class="form-select" 
           required="required"
           aria-label="Default select example">
     <option value="">--Select Student Dept--</option>
     <option value="Science">Science</option>
     <option value="Commerce">Commerce</option>
     <option value="Arts">Art's</option>                    
   </select>
                                                                    
              </div>
         <br><br>
          <div class="col-md-2">
            <button class="btn btn-success login" name="status">Status</button>
          </div>
      </form> <br>
      <h3 class="text-white text-center bg-success py-2">Student Basic info</h3>
            <!-- table code start -->
            <table class="table table-bordered display table-striped" >
              <thead class="text-center">
                <tr>
                  
                  <th>Name</th>
                  <th>Student ID</th>
                  <th>Group</th>
                  <th>Subject Code</th>
                  
                  <th>Session</th>
                </tr>
              </thead>
              <tbody id="myDIV">
                   <?php
                    $select = "SELECT * FROM add_student 
                    WHERE studentid = '$studentid' AND year = '$year' 
                    AND department = '$department' ";

                    $quary = mysqli_query($con,$select);
                    $count=1;
                    $row = mysqli_fetch_array($quary)
                    ?>
                <tr>
                  <?php
                   if($row){ ?>
                    
                  <td><?php echo $row['name'] ?></td> 
                  <td><?php echo $row['studentid'] ?></td> 
                  <td><?php echo $row['department'] ?></td> 
                  <td><?php echo $row['subname'] ?></td> 
                 
                  <td><?php echo $row['year'] ?></td> 
                  <?php 
                  }
                   ?>
                </tr>
              </tbody>
            </table>
            <!-- table Code End -->

            <!-- result code start here -->
 <div class="main_result">
    <h3 class="text-dark text-uppercase text-center py-2 text-decoration-underline">Exam Result </h3>
    <form method="POST">
    
               <?php
              if($department=='Science'){ ?>
               <table class="table table-bordered">
               <thead class="text-center bg-success text-white">
               <tr>
                  <th>SL</th>
                  <th>Subject Code</th>
                  <th>Subject Name</th>                 
                  <th>CQ</th>
                  <th>Practical</th>
                  <th>MCQ</th>
                  <th>Marks</th>
                  <th>Latter</th>
                  
                </tr>
               </thead>
               
               <tbody>
                
                <?php
                $select = "SELECT * FROM science";
                $quary = mysqli_query($con,$select);
                $count=1;
                
                while($row = mysqli_fetch_array($quary)){ ?>
                          <tr>
                            <td><?php echo $count++ ?></td>
                            <td><?php echo $row['subject'] ?></td>
                            <td><?php echo $row['courseid'] ?></td>
                 
                            <td><input type="number" name="cq[]" onblur="findTotal()" id="amount"  class="form-control amount amount2"></td>                           
                            <td><input type="number" name="lab[]" onblur="findTotal()" id="amount" class="form-control amount amount2"></td>                                                                    
                            <td><input type="number" name="mcq[]" onblur="findTotal()" id="amount" class="form-control amount amount2"></td>                                                                            
                            <td><input type="number" name="marks[]" id="total" readonly class="form-control"></td>               
                            <td><input type="number" name="marks[]" id="total2" readonly class="form-control"></td>               
                           
                            <td><input type="number" name="latter[]" id="latter" readonly class="form-control"></td>                                                     
                           </tr>
                         
                          <?php 
                            }                   
                          ?> 
                            
                          </tbody>
              </table> 

             <?php 
            } elseif($department=='Commerce'){ ?>
              <table class="table table-bordered">
               <thead class="text-center bg-success text-white">
               <tr>
                  <th>SL</th>
                  <th>Subject Code</th>
                  <th>Subject Name</th>
                  <th>CQ</th>
                  
                  <th>Practical</th>
                  <th>MCQ</th>
                  <th>Marks</th>
                  <th>Latter</th>
                </tr>
               </thead>
               <tbody>
              <?php            
                  $select = "SELECT * FROM commerce";
                  $quary = mysqli_query($con,$select);
                  $count=1;
                  while($row = mysqli_fetch_array($quary)){ ?>
                    <tr>
                      <td><?php echo $count++ ?></td>
                      <td><?php echo $row['subject'] ?></td>
                      <td><?php echo $row['courseid'] ?></td>

                      <td><input type="number" name="cq[]" id="cq" onblur="findTotal()" id="amount"  class="form-control amount"></td>     
                      <td><input type="number" name="lab[]" id="lab" onblur="findTotal()" id="amount"  class="form-control amount"></td>            
                      <td><input type="number" name="mcq[]" id="mcq" onblur="findTotal()" id="amount"  class="form-control amount"></td>       
                      <td><input type="number" name="marks[]" id="total" readonly class="form-control"></td>
                      <td><input type="text" name="latter[]" id="latter" readonly class="form-control"></td>                           
                
                    </tr>      
                   <?php 
                     } 
              
             }elseif($department=='Arts'){ ?>
              <table class="table table-bordered">
               <thead class="text-center bg-success text-white">
               <tr>
                  <th>SL</th>
                  <th>Subject Code</th>
                  <th>Subject Name</th>
                  <th>CQ</th>  
                  <th>Practical</th>            
                  <th>MCQ</th>
                  <th>Marks</th>
                  <th>Latter</th>
                </tr>
               </thead>
               <tbody>
              <?php            
 $select = "SELECT * FROM arts";
 $quary = mysqli_query($con,$select);
 $count=1;
 while($row = mysqli_fetch_array($quary)){ ?>
           <tr>
             <td><?php echo $count++ ?></td>
             <td><?php echo $row['subject'] ?></td>
             <td><?php echo $row['courseid'] ?></td>

             <td><input type="number" name="cq[]" id="cq" onblur="findTotal()" id="amount"  class="form-control amount"></td>
             <td><input type="number" name="lab[]" id="lab" onblur="findTotal()" id="amount"  class="form-control amount"></td>
             <td><input type="number" name="mcq[]" id="mcq" onblur="findTotal()" id="amount"  class="form-control amount"></td>        
             <td><input type="number" name="marks[]" id="total" readonly class="form-control"></td> 
             <td><input type="text" name="latter[]" id="latter" readonly class="form-control"></td>                           
           </tr>
    
           <?php 
             }            
             }
             ?>   
                                                         
                </tbody>
              </table>             
              <button class="btn btn-success" name="submit">Submit</button>
         
            </div>
            </form>


          
            </div>
           </div>
          </div>                            
         </div>        
         
  


  
  <!-- result code end here -->

        <!-- footer code start -->       
        <footer class="footer text-center">       
          <a href="index.php"> Sonargaon College</a>.
        </footer>    
      </div>    
    </div>

    <!-- Required Js files -->   
<!-- marks auto calculation js code -->
<script>
    function findTotal(){
    var arr = document.getElementsByClassName('amount');
    var arr = document.getElementsByClassName('amount2');
    var tot=0;
    
    for(var i=0;i<arr.length;i++){
        if(parseFloat(arr[i].value))
            tot += parseFloat(arr[i].value);
            
    }
    document.getElementById('total').value = tot;
    document.getElementById('total2').value = tot;
}
</script>

     <!-- Year select js code start-->
     <script>
      function selectYear(){
        var d=new Date();
        var currentYear=d.getFullYear();
        var str = "<option class='text-center' value='0'> --Select Year-- </option>";
        for(var i=0; i<20;i++){
          str+="<option>"+ parseInt(currentYear+i) +"</option>";
        }
        document.getElementById('yearSelection').innerHTML=str;
      }
    </script>
<!-- Year select js code end-->

<script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>






