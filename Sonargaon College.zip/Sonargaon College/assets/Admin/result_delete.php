<?php
 include 'db.php';
$reidNo = $_GET['reidNo'];
$delete = "DELETE FROM tblresult WHERE id = $reidNo";
$ex1 = mysqli_query($con,$delete);
header("location:manage_result.php");
 ?>