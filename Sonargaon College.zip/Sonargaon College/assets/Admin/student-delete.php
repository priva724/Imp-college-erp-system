<?php
 include 'db.php';
$stdid = $_GET['stidNo'];
$img_name = $GET['img_name'];
$delete = "DELETE FROM add_student WHERE id = $stdid";
$ex1 = mysqli_query($con,$delete);
  if($ex1){
    unlink("assets/images$img_name"); 
    header("location:manage_student.php");
  }else{
    echo "delete failde";
  }

 ?>