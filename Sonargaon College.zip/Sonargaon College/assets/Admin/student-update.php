<?php
 include 'db.php';
 session_start();
$stupdate = $_GET['stdup'];
$select = "SELECT * FROM add_student WHERE id = $stupdate";
$ex = mysqli_query($con,$select);
$row =mysqli_fetch_array($ex);

if(isset($_POST['update'])){
  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $studentid = $_POST['studentid'];
  $year = $_POST['year'];
  
  $age = $_POST['age'];
  $gender = $_POST['gender'];
  $fathername = $_POST['fathername'];
  $mothername = $_POST['mothername'];
  $department = $_POST['department'];
  $class = $_POST['class'];

  $update = "UPDATE add_student SET name='$name',
            phone='$phone',
            studentid='$studentid',
            year='$year',
            
            age='$age',
            gender='$gender',
            fathername='$fathername',
            mothername='$mothername',
            department='$department',
            class='$class' WHERE id = $stupdate ";

     $quary = mysqli_query($con,$update);
     header("location:manage_student.php");
     if($qauary){
      echo "<script>alert('Data update success')</script>";    
   }else{
    echo "<script>alert('Data update failed')</script>";
   } 
}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />

   <style>
     .body{
      
      font-family: var_dump;
     }
    
   </style>
</head>
<body class="bg-light-info body" onload="selectYear()">

<a href="manage_student.php"><h1 class="bg-dark text-white text-center my-4">
  Update Student info</h1></a>
  <div class="container-fluid">
  
  <div class="container">
    <div class="row">
      <div class="col-12">
        <section>                        
         
          <form id="my-stud" method="POST">
                 <label for="StudentName" >Student Name</label><br>
                 <input value="<?php echo $row['name'] ?>" name="name" type="text"
                        id="StudentName" class="form-control form-control-lg"
                        placeholder="Enter Studeant Name">
                 <label for="phone">Student Phone Number</label><br>
                 <input value="<?php echo $row['phone'] ?>" name="phone" type="text"
                        id="phone" class="form-control form-control-lg"
                        placeholder="Enter Phone Number">
                 <label for="StudentID">Student ID</label><br>
                 <input value="<?php echo $row['studentid'] ?>" name="studentid" type="text"
                        id="StudentID" class="form-control form-control-lg"
                        placeholder="Enter Studeant ID">
                 <label for="year">Session</label><br>
                 <select name="year" 
                         required="required"
                         class="form-control" id="yearSelection">
                 </select>
               
                 <label for="Studentage">Student Age</label><br>
                 <input value="<?php echo $row['age'] ?>" name="age" type="date"
                        id="Studentage" class="form-control form-control-lg"
                        placeholder="Enter Studeant Age"><br>
                
                <h5>Gender</h5>
                <div class="form-check">                 
                     <input value="<?php echo $row['gender'] ?>" class="form-check-input" type="radio" 
                     name="gender" id="female">
                     <label class="form-check-label" for="female">
                        <h4>FeMale</h4>
                     </label>   
                                     
                </div>
                <div class="form-check">
                     <input value="<?php echo $row['gender'] ?>" class="form-check-input"
                      type="radio"  name="gender" id="male">
                     <label class="form-check-label" for="male">
                      <h4>Male</h4>
                     </label>                    
                </div>

                 <label for="F_name">Father's Name</label><br>
                 <input value="<?php echo $row['fathername'] ?>" name="fathername" type="text"
                        id="F_name" class="form-control form-control-lg"
                        placeholder="Enter Studeant Father Name" >
                 <label for="M_name">Mother's Name</label><br>
                 <input value="<?php echo $row['mothername'] ?>" name="mothername" type="text"
                        id="M_name" class="form-control form-control-lg"
                        placeholder="Enter Studeant Mother Name" >
                
                 <label for="class">Select Department</label><br>
                 <select value="<?php echo $row['department'] ?>" 
                 name="department" id="department" class="form-select"
                 aria-label="Default select example">
                 <option value>Select Student Dept</option>           
                    <option value="Science">Science</option>
                    <option value="Commerce">Commerce</option>
                    <option value="Arts">Art's</option>                    
                </select> 

                 <label for="class">Select Class</label><br>
                 <select value="<?php echo $row['class'] ?>" name="class"
                  class="form-select" id="class" aria-label="Default select example">
                    <option value>Select Admission Class</option>
                    <option value="Inter-I">Inter-I</option>
                    <option value="Inter-II">Inter-II</option>                    
                </select>  <br>
                <button name="update" id="update" class="btn btn-primary p-2">UPDATE</button>  
             </form><br>

        </section>
      </div>
    </div>
  </div>
  </div>



<!-- Required Js files -->
<!-- Year select js code start-->
<script>
      function selectYear(){
        var d=new Date();
        var currentYear=d.getFullYear();
        var str = "<option value='0'> --Select Year-- </option>";

        for(var i=0; i<20;i++){
          str+="<option>"+ parseInt(currentYear+i) +"</option>";
        }
        document.getElementById('yearSelection').innerHTML=str;
      }
    </script>
<!-- Year select js code end-->

  <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
</body>
</html>

<!-- Develope by "Freelancer: Muhammad Mijanur Rahman, 
                  1.Full stack webdeveloper, 
                  2.Digital Marketer, SEO expert" -->