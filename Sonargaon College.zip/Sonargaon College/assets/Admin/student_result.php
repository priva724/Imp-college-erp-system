<!-- serarching code start here -->
<!-- <?php
include 'db.php';

// $studentid = $_REQUEST['studentid'];
$year = $_REQUEST['year'];
$department = $_REQUEST['department'];
if(isset($studentid)){//if keyword set goes here
 $query = "SELECT * FROM add_student WHERE studentid LIKE '%$studentid%' 
 AND year LIKE '%$year%' AND department LIKE '%$department%'";
  if(isset($department)){
    $query = "AND department LIKE '%$department%'";
  }
  if(isset($year)){
    $query = "AND year LIKE '%$year%'";
  }
}else if (isset($studentid)){ //if keyword not set but category set then goes here
 $query = "SELECT * FROM add_student WHERE studentid LIKE '%$studentid%'";
 if(isset($year)){
   $query  = "AND year LIKE '%$year%'";
 }
}else if(isset($department)){//if only country set goes here
 $query = "SELECT * FROM add_student WHERE department LIKE '%$department%'";
}
?> -->

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

  <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />  
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>  
 
  </head>
  <body>

    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
      <svg
        class="tea lds-ripple"
        width="37"
        height="48"
        viewbox="0 0 37 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M27.0819 17H3.02508C1.91076 17 1.01376 17.9059 1.0485 19.0197C1.15761 22.5177 1.49703 29.7374 2.5 34C4.07125 40.6778 7.18553 44.8868 8.44856 46.3845C8.79051 46.79 9.29799 47 9.82843 47H20.0218C20.639 47 21.2193 46.7159 21.5659 46.2052C22.6765 44.5687 25.2312 40.4282 27.5 34C28.9757 29.8188 29.084 22.4043 29.0441 18.9156C29.0319 17.8436 28.1539 17 27.0819 17Z"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          d="M29 23.5C29 23.5 34.5 20.5 35.5 25.4999C36.0986 28.4926 34.2033 31.5383 32 32.8713C29.4555 34.4108 28 34 28 34"
          stroke="#2962FF"
          stroke-width="2"
        ></path>
        <path
          id="teabag"
          fill="#2962FF"
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M16 25V17H14V25H12C10.3431 25 9 26.3431 9 28V34C9 35.6569 10.3431 37 12 37H18C19.6569 37 21 35.6569 21 34V28C21 26.3431 19.6569 25 18 25H16ZM11 28C11 27.4477 11.4477 27 12 27H18C18.5523 27 19 27.4477 19 28V34C19 34.5523 18.5523 35 18 35H12C11.4477 35 11 34.5523 11 34V28Z"
        ></path>
        <path
          id="steamL"
          d="M17 1C17 1 17 4.5 14 6.5C11 8.5 11 12 11 12"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke="#2962FF"
        ></path>
        <path
          id="steamR"
          d="M21 6C21 6 21 8.22727 19 9.5C17 10.7727 17 13 17 13"
          stroke="#2962FF"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        ></path>
      </svg>
    </div>

    <!-- Main wrapper - style you can find in pages.scss -->  
    <div id="main-wrapper">
      <!-- Topbar header - style you can find in pages.scss -->      
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">
            <!-- This is for the sidebar toggle which is visible on mobile only -->
            <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>
     
            <!-- Logo -->            
            <a class="navbar-brand" href="index.php">
              <!-- Logo icon -->
              <b class="logo-icon"></b>                             
              </b>                                          
              <span class="logo-text">  
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>         
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
         <div class="navbar-collapse collapse" id="navbarSupportedContent">
           
           <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <!-- mega menu -->
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >                 
                </a>                
              </li>                 
            </ul>                   
          </div>
        </nav>
      </header>
      <!-- End Topbar header -->
   
      <!-- Left Sidebar include here -->   
      <?php
       include_once 'main_menu.php';
      ?>
  <!-- Page wrapper  -->

      <div class="page-wrapper">
        
        <!-- Container fluid  -->  
        <div class="container-fluid">       
          <!-- main page code start -->

          <div class="row">
            <div class="col-1">
            <a href="index.php" class="text-primary"><h4>Dashboard</h4></a>
            </div>
            <div class="col-12 row">
           <div class="result">
           <form method="post" class="row">
              <!-- <div class="col-md-4">
              <label for="stid">Student ID<span class="text-danger">*</span></label><br>
                <input id="stid" type="text" 
                       name="studentid"
                       require="require" 
                       placeholder="Student ID" 
                       class="form-control"><br>
              </div> -->
              <div class="col-6" >
              <label for="yearSelection" class="text-dark text-uppercase">
                Session<span class="text-danger">*</span></label><br>                           
              <!-- <select name="year" 
                      required="required"
                      class="form-control" id="yearSelection">
              </select><br> -->
            <select name="year" 
              required="required"
              class="form-control" >
              <option value="" selected disabled>--session--</option>
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2026-2027">2026-2027</option>
              <option value="2027-2028">2027-2028</option>
              <option value="2028-2029">2028-2029</option>
              <option value="2029-2030">2029-2030</option>
              <option value="2030-2031">2030-2031</option>
            </select>
          </div>

              <div class="col-md-6">
               
                    <label for="department">Group<span class="text-danger">*</span></label><br>
                    <select name="department" class="form-select" required="required"
                    aria-label="Default select example">
                  <option value="">--Select Student Dept--</option>
                  <option value="Science">Science</option>
                  <option value="Commerce">Commerce</option>
                  <option value="Arts">Art's</option>  
                                 
                  </select>                                  
              </div>   

              <br><br>
          <div class="col-md-2 mt-1">
            <button class="btn btn-success login" name="status">Status</button>
          </div>
      </form><br>
         
      <h3 class="text-white text-center bg-success py-2">Student Basic info</h3>
            <!-- table code start -->
            <table id="myTable" class="table table-bordered display table-striped overflow-scroll text-uppercase" >
              <thead class="text-center">
                <tr>
                  
                  <th>Name</th>
                  <th>Student ID</th>
                  <th>Group</th>
                  <th>Session</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="myDIV">
              <tbody class="text-uppercase">
                    <?php
                      $select = "SELECT * FROM add_student  where department='$department'
                       AND year='$year'";
                      $query = mysqli_query($con,$select);
                     
                      while($row = mysqli_fetch_array($query)){?>
                          <tr>
                          
                            <td><?php echo $row['name'] ?></td> 
                            <td><?php echo $row['studentid'] ?></td> 
                            <td><?php echo $row['department'] ?></td> 
                            <td><?php echo $row['year'] ?></td>
                            <td>
                            <a href="insert_result.php?stdresult=<?php echo $row['id']?>">
                            <button class="btn btn-success">Action</button></a>
                            </td>
                          
                        </tr>
                     <?php
                      }
                    ?>
                                         
                  </tbody>
             
              </tbody>
            </table>
            <!-- table Code End -->

            <!-- Result Code insert here -->
           

           </div>

            </div>
            </div>
          </div>
        
        </div>


        <!-- footer code start -->       
        <footer class="footer text-center">       
          <a href="index.php"> Sonargaon College</a>.
        </footer>    
      </div>    
    </div>

    <!-- Required Js files -->   
    <script>
      $(document).ready( function () {
    $('#myTable').DataTable();
      } );
    </script>

     <!-- ajax code  -->
     <!-- <script>
          $("#mysubject").submit(function(e){
          e.preventDefault();
          $ajax({
            url:"insert_code.php",
            method:"post",
            data: new FormData(this),
            success: function(res){
            console.log(res);
            }

          })
         })
         </script> -->

    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>
