<?php
 include 'db.php';
$subjectdelete = $_GET['subjectdelete'];
$delete = "DELETE FROM subject_details WHERE id = $subjectdelete";
$ex1 = mysqli_query($con,$delete);
header("location:subject_details.php");
 ?>