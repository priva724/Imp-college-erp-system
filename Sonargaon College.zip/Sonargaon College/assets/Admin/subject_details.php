<!-- subject details php insert code here -->

<?php 
include 'db.php';
if(isset($_POST['submit'])){
  $subject_code = $_POST['subject_code'];
  $subject_title = $_POST['subject_title'];
  $subject_exam_type = $_POST['subject_exam_type'];
  $subject_type = $_POST['subject_type'];
  $dept = $_POST['dept'];

  $check = "SELECT * FROM subject_details where subject_code='$subject_code'";
  $ex1 = mysqli_query($con,$check);
  $count = mysqli_num_rows($ex1);
  if($count>0){
    echo "<script>alert('Subject code already Exsits')</script>";
  }else{
    $insert= "INSERT INTO `subject_details` (`subject_code`, 
    `subject_title`, `subject_exam_type`, `subject_type`, `dept`) VALUES 
    ('$subject_code', '$subject_title', '$subject_exam_type', 
    '$subject_type', '$dept')";
  
    $ex = mysqli_query($con,$insert); 
    if($ex){
      echo "<script>window.location='subject_details.php'</script>";
    }else{
      echo "<script>alert('Data insert failed')</script>";
    }
  }
}
?>
<!-- subject details end here -->
<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex,nofollow" />
    <title>Sonargaon College</title>
    <link rel="canonical" href="https://therichpost.com" />
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/Logo.png" />
    <link rel="stylesheet" href="assets/css/apexcharts.css" />
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet" />
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />  
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>  
 
  </head>
  <body>

   <div id="main-wrapper">
     <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header">        
            <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
            >
              <i class="ri-close-line fs-6 ri-menu-2-line"></i>
            </a>                       
            <a class="navbar-brand" href="index.php">            
              <b class="logo-icon"></b>                             
              </b>       
              <span class="logo-text">            
                <h3 class="text-black pt-4 px-4 text-bg-light-primary">SONARGAON <br> COLLEGE</h3>
              </span>
            </a>
        
            <a
              class="topbartoggler d-block d-md-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ri-more-line fs-6"></i
            ></a>
          </div>
         
         <div class="navbar-collapse collapse" id="navbarSupportedContent">
           <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-md-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i data-feather="menu" class="feather-sm"></i
                ></a>
              </li>
              <li class="nav-item dropdown mega-dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  role="button"
                  href="#"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >                  
                </a>                
              </li>                    
            </ul>                     
          </div>
        </nav>
      </header>
      <!-- End Topbar header -->   
      <!-- Left Sidebar include here -->
   
      <?php
       include_once 'main_menu.php';
      ?>
  <!-- Page wrapper  -->

      <div class="page-wrapper">
        
        <!-- Container fluid  -->  
        <div class="container-fluid">       
          <!-- main page code start -->
           <div class="row">           
            <div class="col-12">
            <form class="row" id="mysubject" method="post">            

          <div class="col-6">
          <label for="subjectname">Subject Title<span class="text-danger">*</span></label><br>
          <input type="text" 
          id="subjectname" required="required"
          name="subject_title" 
          class="form-control form-control-lg"
          placeholder="Subject Title">
          </div>
          <div class="col-6">
          <label for="subject_code">Subject Code<span class="text-danger">*</span></label><br>
          <input type="text" 
          id="subject_code" 
          name="subject_code" 
          class="form-control form-control-lg"
          required="required"
          placeholder="Subject Code"> 
          </div>              
          <br>           
         <div class="col-lg-6">
         <label for="subject_exam_type">Subject Exam Type<span class="text-danger">*</span></label>
            <select name="subject_exam_type" id="" class="form-control form-control-lg" 
            aria-label=".form-select-sm example" required="required">
           
            <option value="" selected="selected" disabled>--exam_type--</option>
       
              <option value="theory">Theory</option>
              <option value="practical">Practical</option>
              <option value="both">Both</option>
            </select> 
         </div>

         <div class="col-lg-6">
         <label for="subject_type">Subject Type<span class="text-danger">*</span></label>    
            <select name="subject_type" id="" class="form-control form-control-lg" 
            aria-label=".form-select-sm example" required="required">
            <option value="" selected="selected" disabled>--subject_type--</option>
       
              <option value="compulsory">Compulsory</option>
              <option value="optional">Optional</option>
              <option value="all">ALL</option>
            </select> 
         </div>

         <div class="col-lg-6">
         <label for="dept">Group<span class="text-danger">*</span></label>    
            <select name="dept" id="dept" class="form-control form-control-lg" 
            aria-label=".form-select-sm example" required="required">
            <option value="" selected="selected" disabled>--Group--</option>
       
              <option value="science">Science</option>
              <option value="commerse">Commerse</option>
              <option value="arts">Art's</option>
              <option value="all">ALL</option>
            </select> 
         </div>
         <div class="col-6">

         </div>
          <div class="col-2">
          <button name="submit" class="btn btn-primary p-2 mt-2">Submit</button>
    
          </div>
       </form><br>

       <h3 class="text-dark text-uppercase 
       text-center text-white bg-success py-2">Subject Details</h3>
               <br>

               <table id="myTable" class="table table-bordered display text-dark ">
                  <thead class="text-uppercase">
                      <tr>
                      <th>SL</th>
                      <th>Subject Code</th>
                      <th>Subject Title</th>                  
                      <th>Subject Exam Type</th>
                      <th>Subject Type</th>
                      <th>Group</th> 
                      <th>Edit</th> 
                      <th>Delete</th>                                     
                      </tr>
                  </thead>
                  <tbody>
                  <?php
                      $select = "SELECT * FROM subject_details";
                      $query = mysqli_query($con,$select);
                      $countr = 1;
                      while($row = mysqli_fetch_array($query)){?>

                          <tr>
                              <td><?php echo $countr++ ?></td>
                             
                              <td><?php echo $row['subject_code'] ?></td>
                              <td><?php echo $row['subject_title'] ?></td>
                              <td><?php echo $row['subject_exam_type'] ?></td>
                              <td><?php echo $row['subject_type'] ?></td>
                              <td><?php echo $row['dept'] ?></td>
                              <td><a href="subject-update.php?subjectupdate=<?php echo $row['id']?>">
                              <button class="btn btn-success">Edit</button>
                            </td>
                            <td><a onclick="return confirm('are you sure?')" 
                              href="subject_delete.php?subjectdelete=<?php echo $row['id']?>">
                              <button class="btn btn-danger">Delete</button></a>
                            </td>                       
                        </tr>
                     <?php
                      }
                    ?>                   
                  </tbody>
         </table>  
 
        
            </div>
            </div>
          </div>
        
        </div>


        <!-- footer code start -->       
        <footer class="footer text-center">       
          <a href="index.php"> Sonargaon College</a>.
        </footer>    
      </div>    
    </div>

    <!-- Required Js files -->   
     <!-- ajax code  -->
     <!-- <script>
          $("#mysubject").submit(function(e){
          e.preventDefault();
          $ajax({
            url:"insert_code.php",
            method:"POST",
            data: new FormData(this),
            success: function(res){
              console.log(res);
            }

          })
         })
         </script> -->

    <!-- data table code start -->
    <script>
      $(document).ready( function () {
    $('#myTable').DataTable();
      } );
    </script>

   
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Theme Required Js -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <!-- perfect scrollbar JavaScript -->
    <script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/js/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
   
    <!-- This page JavaScript -->
    
    <script src="assets/js/apexcharts.min.js"></script>
    <script src="assets/js/dashboard1.js"></script>
  </body>
</html>
