<?php
include 'db.php';

$viewstd = $_GET['viewstd'];
$select = "SELECT * FROM add_student where id=$viewstd";
$ex = mysqli_query($con,$select);
$row = mysqli_fetch_array($ex);

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sonargaon Colle</title>
  <link type="Image" rel="icon" href="assets/images/Logo.png">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="assets/CSS/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <style>
      .collegeinfo{
        background: #172541;
        color: wheat;
        text-align: center;
        border-radius: 10px;
        padding: 10px 0;
      }
      .collegeinfo a img{
       
        padding: 10px 0;
      }
      .collegeinfo h2{
        color: wheat;
      }
      .collegeinfo h4{
        color: wheat;
        display: inline-block;
      }
      .studentinfo{
        padding: 5px 20px;
      }
      .img img{
        border-radius: 5px;
      }
    </style>
</head>
<body>

<div class="container-fluid ">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="collegeinfo">
         <a href="index.php">
             <img src="assets/images/Logo.png" 
             alt="sonargaoncollege" width="100" height="100">
          </a>

          <h2 >Sonargaon College</h2>
          <h4>147/I Green Road, Dhaka</h4>
        </div>        
      </div>
      <h2 class="text-center">Student info</h2>
          <hr>
      <div class="col-9">
      <div class="studentinfo">
          
          <table class="table table-bordered border-primary">
            <thead>
              <tr>
                <th>Name</th>
                <td><?php echo $row['name'] ?></td>
                
              </tr>
              <tr>
                <th>Phone:</th>                
                <td><?php echo $row['phone'] ?></td>
               
              </tr>
              <tr>
                <th>Student ID:</th>                
                <td> <?php echo $row['studentid'] ?></td> 
              </tr>
              <tr>
                <th>Age:</th>                
                <td> <?php echo $row['age'] ?></td> 
              </tr>
              <tr>
                <th>Gender:</th>                
                <td> <?php echo $row['gender'] ?></td> 
              </tr>
              <tr>
                <th>Father Name:</th>                
                <td> <?php echo $row['fathername'] ?></td> 
              </tr>
              <tr>
                <th>Mother Name:</th>                
                <td> <?php echo $row['mothername'] ?></td> 
              </tr>
              <tr>
                <th>Departnemt:</th>                
                <td> <?php echo $row['department'] ?></td> 
              </tr>
              <tr>
                <th>Class:</th>                
                <td> <?php echo $row['class'] ?></td> 
              </tr>
            </thead>
          </table>          
          
          <h5 class="text-center">Date: <?php echo date('d-m-y') ?></h5>         
          <button id="printBtn" class="btn btn-primary">Print</button><br><br><br>        
        </div>
      </div>
      <div class="col-2">
          <div class="img">
          <img src="assets/images/<?php echo $row['image'] ?>" alt=""
          width="175" height="200">
          <h6 class="text-center mt-2"><?php echo $row['name'] ?></h6>
          </div>
      </div>
      <div class="col-lg-1">

      </div>
    </div>
  </div>
</div>



<!-- JS Link here -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="assets/js/owl.carousel.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <script>
      var printBtn = document.getElementById("printBtn");
        printBtn.addEventListener("click",function(){
        printBtn.style.display = "none";
        window.print();
      })
    </script>
</body>
</html>